import { auth } from "./FirebaseConfig";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider } from "firebase/auth";
export const doSigninWithEmailAndPassword = (email, password) => {
  return signInWithEmailAndPassword(auth, email, password);
}
export const doSignInWithGoogle = async () => {
  const provider = new GoogleAuthProvider();
  const result = await signInWithPopup(auth, provider);
  return result
}